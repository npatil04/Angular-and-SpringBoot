import { Component, OnInit } from '@angular/core';
import { Login } from './login';
import { LoginserviceService } from './loginservice.service';
import { User } from '../user/user';
import { Router } from '@angular/router'
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  Login: Login = new Login();
  public submit = 'submit';
  user: User[];

  loginForm: FormGroup;

  constructor(private formBuilder: FormBuilder, private loginservice: LoginserviceService, private Router: Router) {



  }

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
    });

  }

  onSubmit() {
    console.log(this.loginForm)
    if (this.loginForm.invalid == true) {
      console.log("invalid")
      return;
    } else {
      this.Login.username = this.loginForm.controls.username.value;
      this.Login.password = this.loginForm.controls.password.value;
      console.log(Login);
      this.login();
    }
  }


  login() {
    this.loginservice.loginservice(this.Login);

  }

  logout() {
    this.loginservice.logout();
  }
}
