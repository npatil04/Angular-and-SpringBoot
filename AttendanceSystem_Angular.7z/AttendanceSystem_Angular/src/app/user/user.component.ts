import { Component, OnInit } from '@angular/core';
import { User } from './user';
import { UserserviceService } from './userservice.service';
import { ExcelServicesService } from '../services/excel-services.service';

import { FormControl } from '@angular/forms';
import { LoginserviceService } from '../login/loginservice.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component(
  {
    selector: 'app-user',
    templateUrl: './user.component.html',
    styleUrls: ['./user.component.css']
  }
)

export class UserComponent implements OnInit {

  registerForm: FormGroup;

  selected = new FormControl(0);
  excel = [];
  user: User = new User
  scopeName: Boolean
  userlist: User[];
  searchText;
  constructor(private formBuilder: FormBuilder, private UserserviceService: UserserviceService, private loginservice: LoginserviceService, private excelService: ExcelServicesService) { }


  ngOnInit() {

    this.registerForm = this.formBuilder.group({
      username: ['', Validators.required],
      address: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]],
      firstname: ['', [Validators.required, Validators.pattern("[a-zA-Z ]*")]],
      lastname: ['', [Validators.required, Validators.pattern("[a-zA-Z ]*")]],
      userGroup: ['', Validators.required],
      leavecount: ['', [Validators.required, Validators.maxLength(2)]],
      mobile: ['', [Validators.required, Validators.pattern('[789][0-9]{9}')]]
    });

    this.getuser()
  }

  onSubmit() {
    console.log(this.registerForm);
    if (this.registerForm.invalid == true) {
      console.log("invalid")
      return;
    } else if (this.registerForm.invalid == false) {
      this.user.username = this.registerForm.controls.username.value;
      this.user.email = this.registerForm.controls.email.value;
      this.user.password = this.registerForm.controls.password.value;

      this.user.firstname = this.registerForm.controls.firstname.value;
      this.user.lastname = this.registerForm.controls.lastname.value;
      this.user.userGroup = this.registerForm.controls.userGroup.value;

      this.user.leavecount = this.registerForm.controls.leavecount.value;
      this.user.phone = this.registerForm.controls.mobile.value;
      this.user.address = this.registerForm.controls.address.value;

      this.adduser();
     
    }
  }


  exportAsXLSX(): void {
    this.userlist.forEach(row => {

      this.excel.push(row);
    });
    this.excelService.exportAsExcelFile(this.excel, 'Employee Data');
  }

  logout() {
    this.loginservice.logout();
  }
  getuser() {
    this.UserserviceService.getuser().subscribe(data => { this.userlist = data })
  }

  adduser() {
    // alert(this.user.empId)
    if (this.user.empid > 0) {
      this.UserserviceService.updateuser(this.user, this.user.empid).subscribe(data => { this.userlist = data ;alert("Successfully Updated...!") } )
     
    }
    else {
      this.UserserviceService.adduser(this.user).subscribe(data => { this.userlist = data; console.log(this.userlist); alert("Successfully Registered...!"); })
     }

    this.registerForm.reset();
  }

  clear() {
    this.user.address = ""
    this.user.email = ""
    this.user.firstname = ""
    this.user.lastname = ""
    this.user.password = ""
    this.user.phone = ""
    this.user.userGroup = ""
    this.user.leavecount = ""
    this.user.username = ""
    this.user.empid = 0
  }

  delete(empid: number) {
    //this.userlist = [];
  
    if(confirm("Are you sure u want to delete?")){
      debugger
      this.UserserviceService.deleteuser(empid).subscribe(data => { this.userlist = data })
    }
  }
  update(empid: number) {
    tabnumber: Number
    console.log(empid);
    this.scopeName = true

    var userfind = this.userlist.find(x => x.empid == empid);
    this.UserserviceService.getuser().subscribe(data => { this.userlist = data })
    console.log(this.userlist);
    this.user.address = userfind.address
    this.user.email = userfind.email
    this.user.firstname = userfind.firstname
    this.user.lastname = userfind.lastname
    this.user.password = userfind.password
    this.user.phone = userfind.phone
    this.user.userGroup = userfind.userGroup
    this.user.leavecount = userfind.leavecount
    this.user.username = userfind.username
    this.user.empid = userfind.empid
    console.log(this.user);
    this.selected = new FormControl(0);



    this.userlist.forEach(element => {
      console.log("IN");

      if (element.empid == empid) {
        this.registerForm.controls.username.setValue(element.username),
          this.registerForm.controls.email.setValue(element.email),
          this.registerForm.controls.password.setValue(element.password),
          this.registerForm.controls.firstname.setValue(element.firstname),
          this.registerForm.controls.lastname.setValue(element.lastname),
          this.registerForm.controls.userGroup.setValue(element.userGroup),
          this.registerForm.controls.leavecount.setValue(element.leavecount),
          this.registerForm.controls.address.setValue(element.address),
          this.registerForm.controls.mobile.setValue(element.phone);
      }
    });
  }
}