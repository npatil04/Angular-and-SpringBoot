package com.example.AttendanceSystem.Service;

import com.example.AttendanceSystem.Model.User;

public class UserServiceImpl implements UserService 
{
	
	
		
		
	
	
}
