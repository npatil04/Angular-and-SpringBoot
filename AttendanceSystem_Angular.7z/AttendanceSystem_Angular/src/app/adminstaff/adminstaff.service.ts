import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { getMatInputUnsupportedTypeError } from '@angular/material';
import { Leaves } from '../employee/Leaves';
import { User } from '../user/user';

@Injectable({
  providedIn: 'root'
})
export class AdminstaffService {

   
  constructor(private http:HttpClient) { 

  }

    getLeaveList()
     {
       return this.http.get<Leaves[]>("http://localhost:8081/leavelist")
     }
     approveLeave(id: number)
     {
       return this.http.get<Leaves[]>("http://localhost:8081/approve/" + id);
     }
     rejectLeave(id: number)
     {
       return this.http.get<Leaves[]>("http://localhost:8081/reject/" + id);
     }
     getUserList()
     {
       return this.http.get<User[]>("http://localhost:8081/userlist")
     }
     calculateLOP(id: number)
     {
       return this.http.get<Boolean>("http://localhost:8081/calculatelop/" + id);
     }
}
