package com.example.AttendanceSystem.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.AttendanceSystem.Dao.UserDao;
import com.example.AttendanceSystem.Model.Leaves;
import com.example.AttendanceSystem.Model.User;

@RestController
@CrossOrigin(origins = "*")
public class UserController {

	@Autowired
	private UserDao userdao;

	@GetMapping("/userlist")
	private List<User> getAllUsers() {
		return userdao.getAllUsers();

	}
}
