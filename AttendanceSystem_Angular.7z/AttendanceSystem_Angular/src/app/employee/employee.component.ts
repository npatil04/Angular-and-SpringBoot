import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { Leaves } from './Leaves';
import { LossOfPay } from './LossOfPay';
import { Moment } from 'moment';
import { DatePipe } from '@angular/common'
import { EmployeeService } from './employee.service';
import { LoginserviceService } from '../login/loginservice.service';
import { User } from '../user/user';
import { MatInput } from '@angular/material';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {

  employeeForm: FormGroup;
  @ViewChild('dateInput', { static: false }) dateInput: ElementRef;

  datepipe: DatePipe = new DatePipe('en-US');
  leave: Leaves = new Leaves
  lopObj: LossOfPay = new LossOfPay
  minDate: Date
  maxDate: Date
  empId: number
  selected = new FormControl(0);
  success: number
  select: { begin: Moment, end: Moment }
  constructor(private formBuilder: FormBuilder, private employeeservice: EmployeeService, private loginservice: LoginserviceService) {
    this.leave.user = new User
  }



  pickerModes: {
    single: true, // disable/enable single date picker mode
    //multi: true, // disable/enable multiple date picker mode
    range: true // disable/enable range date picker mode
  }

  getDate(event) {
    console.log(event); // logs the picked date data
  }
  ngOnInit() {

    this.employeeForm = this.formBuilder.group({
      remark: ['', Validators.required],
      fromDate: ['', Validators.required],
      toDate: ['', Validators.required],
      days: ['', Validators.required],
      insert: ['', Validators.required],
    }

    )
  }


  onSubmit() {
    console.log(this.employeeForm);
    if (this.employeeForm.invalid == true) {
      console.log("invalid")
      return;
    } else if (this.employeeForm.invalid == false) {
      this.leave.remark = this.employeeForm.controls.remark.value;
      // this.user.email = this.registerForm.controls.email.value;

      this.addleave();
      alert("Successfully Registered...!");
    }
  }
  onLoad(args: any) {
    if (args.date.valueOf() >= new Date().setHours(0, 0, 0, 0) && (args.date.getDay() === 0 || args.date.getDay() === 6)) { // check the date which are saturday and sunday from today onwards.
      args.isDisabled = true; // disable the weekend date
    }
  }
  tabClick(event) {

    switch (event) {
      case 1: this.getLopOfEmployee(); break;
    }
    console.log("event", event);

  }

  updateCalcs() {

    this.leave.days = this.select.end.dayOfYear() - this.select.begin.dayOfYear() + 1

  }
  addleave() {
    this.leave.fromDate = this.datepipe.transform(this.select.begin.toDate(), 'yyyy-MM-dd');
    this.leave.toDate = this.datepipe.transform(this.select.end.toDate(), 'yyyy-MM-dd');

    this.leave.user.empid = +sessionStorage.getItem('empid');
    this.employeeservice.addleave(this.leave, this.leave.user.empid).subscribe(x => { this.success = x; if (this.success == 1) { alert('Leave applied success') } else { alert('Excedded leaves of limit so u cant apply for leaves') } });
    this.leave = new Leaves();
    this.leave.user = new User();
    this.dateInput.nativeElement.innerHTML = '';

    // this.employeeForm.reset();

  }

  logout() {
    this.loginservice.logout();
  }

  setEmpId() {
    this.empId = Number(sessionStorage.getItem('empid'));
  }

  getLopOfEmployee() {
    this.empId = Number(sessionStorage.getItem('empid'));
    this.employeeservice.getEmpLop(this.empId).subscribe(data => { this.lopObj = data })
  }
}