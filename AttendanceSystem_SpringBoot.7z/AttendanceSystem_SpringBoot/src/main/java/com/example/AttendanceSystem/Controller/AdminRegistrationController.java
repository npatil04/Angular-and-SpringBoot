package com.example.AttendanceSystem.Controller;

import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.AttendanceSystem.Dao.UserDao;
import com.example.AttendanceSystem.Model.User;

/**
 * @author narpatil
 *
 */
@RestController
@CrossOrigin(origins = "*")
public class AdminRegistrationController {
	@Autowired
	private UserDao userDao;
	
    @PostMapping("/adduser")      //Here we have to isert values in databse i.e @postmapping
	public Iterable<User> adduser(@RequestBody  User user)  
	{
		System.out.println(user.getEmpid());
		
		System.out.println(user.getAddress());
		
		userDao.save(user);
	    int id=3;
		
	    Iterable<User> userlist=userDao.findByusergroup(id);
		
		return userlist;
	}
	
	/**
	 * @return
	 */
	@GetMapping("/getuser")
	public Iterable<User> getuser()  
	{
	    int id=3;
		
	    Iterable<User> userlist=userDao.findByusergroup(id);
		
		return userlist;
	}
}
