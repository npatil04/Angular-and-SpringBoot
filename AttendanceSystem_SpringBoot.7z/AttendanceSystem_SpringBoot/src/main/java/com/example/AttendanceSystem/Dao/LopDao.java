package com.example.AttendanceSystem.Dao;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.AttendanceSystem.Model.Leaves;
import com.example.AttendanceSystem.Model.LossOfPay;

@Transactional
@Repository
public interface LopDao extends CrudRepository<LossOfPay, String> {

	@Query("from LossOfPay  where empid=?1")
	LossOfPay findbyid(int id);
	
	@Modifying
	@Query("update  LossOfPay set lop=?1 where empid=?2")
	void updatebyempid(int lop,int empid);
}
