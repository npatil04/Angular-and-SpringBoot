import { Component } from "@angular/core";

@Component({
    selector: 'app-logout',
    template:'<h2> LogOut Successfully!!</h2>'

})
export class LogoutComponent {

}