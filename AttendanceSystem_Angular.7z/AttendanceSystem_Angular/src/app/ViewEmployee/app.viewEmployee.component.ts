import { Component, OnInit } from '@angular/core';
import { User } from '../user/user';
import { LoginserviceService } from '../login/loginservice.service';
import { UserserviceService } from '../user/userservice.service';

import { ExcelServicesService}  from '../services/excel-services.service'
import { Router } from '@angular/router';
@Component({
    selector: 'app-viewEmployee',
    templateUrl:'./app.viewEmployee.component.html',
    styleUrls: ['./app.viewEmployee.component.css']
})
export class AppViewEmployee implements OnInit {
  user:User=new User
  excel=[];  
  constructor(private UserserviceService:UserserviceService,private excelService:ExcelServicesService,private Router: Router) { }
  userlist:User[];
  ngOnInit() {
    this.getuser()
  }

  getuser()
  {
    this.UserserviceService.getuser().subscribe(data=>{this.userlist=data})
  }
  delete(empid:number)
  {
    alert(empid)
    this.UserserviceService.deleteuser(empid).subscribe(data=>{this.userlist=data})
  }
  
  update(empid:number)
  {
    console.log("Abhi")
    var userfind =  this.userlist.find(x => x.empid ==empid);
    
    this.user.address=userfind.address
    this.user.email=userfind.email
    this.user.firstname=userfind.firstname
    this.user.lastname=userfind.lastname
    this.user.password=userfind.password
    this.user.phone=userfind.phone
    this.user.userGroup=userfind.userGroup
    this.user.leavecount=userfind.leavecount
    this.user.username=userfind.username
    this.user.empid=userfind.empid
    
    this.Router.navigate(['/addEmployee']);
   
}
adduser()
{
  alert(this.user.empid)
    if(this.user.empid>0)
    {
       this.UserserviceService.updateuser(this.user,this.user.empid).subscribe(data=>{this.userlist=data})
       
    }
    else
    {
      this.UserserviceService.adduser(this.user).subscribe(data=>{this.userlist=data;console.log(this.userlist)})

    }
    
    this.clear()
  }
  exportAsXLSX():void {  
    this.userlist.forEach(row => {  
      this.excel.push(row);  
    }); 
    this.excelService.exportAsExcelFile(this.excel, 'sample');  
 }  
  clear()
  {
    this.user.address=""
    this.user.email=""
    this.user.firstname=""
    this.user.lastname=""
    this.user.password=""
    this.user.phone=""
    this.user.userGroup=""
    this.user.leavecount=""
    this.user.username=""
    this.user.empid=0
  }
}
