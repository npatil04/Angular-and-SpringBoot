package com.example.AttendanceSystem.Dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.AttendanceSystem.Model.Leaves;
import com.example.AttendanceSystem.Model.User;

@Transactional
@Repository
public interface UserDao   extends CrudRepository<User, String>
{
	//For login
	@Query("from User where username=?1 and password=?2")
	User findbyuser(String username,String password);
	
	//For Delete
	@Modifying
	@Query("delete from User where empid=?1")
	void deleteuserbyempid(Integer empid);
	
	
     
	@Query("from User where userGroup=?1")
	Iterable<User> findByusergroup(int id);
    
	@Query("from User where empid=?1")
	User findById(int empId);
	
	@Modifying
	@Query("update  User set leavecount=?1 where empid=?2")
	void updatebyempid(int leavecount,int empid);
	
	@Query("from User")
	List<User> getAllUsers();
	
	
	


}
