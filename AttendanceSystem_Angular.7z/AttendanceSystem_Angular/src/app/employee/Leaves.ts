import { User } from '../user/user';

export class Leaves {
    
     id:number;
     user:User;
     remark:string;
    fromDate:string;
     toDate:string;
	 days:number;
}
