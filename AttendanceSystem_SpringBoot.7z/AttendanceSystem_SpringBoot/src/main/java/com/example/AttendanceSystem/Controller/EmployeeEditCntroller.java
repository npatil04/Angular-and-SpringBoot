package com.example.AttendanceSystem.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.AttendanceSystem.Dao.LopDao;
import com.example.AttendanceSystem.Dao.UserDao;
import com.example.AttendanceSystem.Model.LossOfPay;
import com.example.AttendanceSystem.Model.User;

/**
 * @author narpatil
 *
 */
@RestController
@CrossOrigin(origins = "*")
public class EmployeeEditCntroller {
	@Autowired
	private UserDao userDao;
		
	@Autowired
	private LopDao lopDao;

	@PutMapping(value = "/edituser/{id}")
	public Iterable<User> edituser(@RequestBody User user,@PathVariable("id") int id) 
	{
		user.setEmpid(id);;
		int usergroup=3;
		System.out.println(id);
		System.out.println(user.getAddress());
		System.out.println(user.getEmpid());
		userDao.save(user);
		Iterable<User> userlist= (Iterable<User>) userDao.findByusergroup(usergroup);
//		
//		List<User> user = (List<User>) userDao.findAll();
		return userlist;
	}

	@GetMapping("/getEmpLop/{id}")
	public LossOfPay getEmpLop(@PathVariable("id")Integer id)
	{ 
		System.out.println("");
		LossOfPay lop = lopDao.findbyid(id);
		if(lop == null)
		return null;
		System.out.println("Lop id : "+ lop.getLopId());
		return lop;
	}
	
}
