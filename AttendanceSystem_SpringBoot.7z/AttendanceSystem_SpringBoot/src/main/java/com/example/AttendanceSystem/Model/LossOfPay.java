package com.example.AttendanceSystem.Model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreType;

/**
 * @author narpatil
 *
 */
@Entity
@Table(name = "lossofpay")
@JsonIgnoreType
public class LossOfPay {

	@Id
	@GeneratedValue
	private int lopId;

	public int getLopId() {
		return lopId;
	}

	public void setLopId(int lopId) {
		this.lopId = lopId;
	}

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name="empid")
	private User user;

	@Column
	private int lop;

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public int getLop() {
		return lop;
	}

	public void setLop(int lop) {
		this.lop = lop;
	}

	@Override
	public String toString() {
		return "LossOfPay [lopId=" + lopId + ", lop=" + lop + ", user=" + user + "]";
	}
}
