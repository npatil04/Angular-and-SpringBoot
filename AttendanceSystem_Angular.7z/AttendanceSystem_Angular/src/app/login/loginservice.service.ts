import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Login } from './login';
import { User } from '../user/user';

import { stringify } from 'querystring';
import { AuthGuard } from '../auth.guard';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, Router } from '@angular/router';


@Injectable({
  providedIn: 'root'
})
export class LoginserviceService implements CanActivate {
  public user: User
  constructor(private http: HttpClient, private Router: Router) { }
  loginstatus: boolean = false
  isloggedin(): boolean {
    return this.loginstatus;
  }

  loginservice(login: Login) {
    this.user = null
    console.log("Heloo")
    this.http.get<User>("http://localhost:8081/login/" + login.username + "/" + login.password).
      subscribe(data => {

        sessionStorage.setItem('empid', data.empid.toString());
        this.user = data;


        if (this.user.userGroup == "1") 
        {
          this.loginstatus = true;
          this.Router.navigate(['/admin']);
        }
        else if (this.user.userGroup == "3") 
        {
          this.loginstatus = true;
          this.Router.navigate(['/Employee']);
        }

        else if (this.user.userGroup == "2") {
          this.loginstatus = true;

          this.Router.navigate(['/adminstaff']);
        }
        else 
        {
          this.Router.navigate(['/usernavigation']);
        }
      },
        error => {
          alert('Please enter valid credentials');
        }
      );


  }

  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot) {

    if (this.loginstatus == true) {
      return true;
    }
    else {
      this.Router.navigate([''])
      return false;
    }
  }

  logout() {
    sessionStorage.removeItem('empid')
    this.Router.navigate([''])
  }

}
