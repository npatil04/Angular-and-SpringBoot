import { Component } from '@angular/core';
import {Router} from '@angular/router'
import '../polyfills';
import { DataTablesModule } from 'angular-datatables';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'attendancesystem';
  valid = true;
  emp = true; 
  constructor( private Router: Router) {}
  logout() {
    console.log('IN LOGOUT')
    this.Router.navigate(['/logout']);
  }
}
