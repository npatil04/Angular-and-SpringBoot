package com.example.AttendanceSystem.Dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.AttendanceSystem.Model.Leaves;

@Transactional
@Repository
public interface leavesdao extends CrudRepository<Leaves, String> {

	@Query("from Leaves  where status='applied'")
	List<Leaves> findbyremark();

	@Modifying
	@Query("update  Leaves set status='rejected' where id=?1")
	void update(int id);

	@Modifying
	@Query("update  Leaves set status='approve' where id=?1")
	void updateapprove(int id);

	@Query("from Leaves  where   id=?1")
	Leaves findbyid(int id);
	/*
	 * @Modifying
	 * 
	 * @Query("delete from leaves u inner join u l on u.empid = l.empid where u.empid=?1"
	 * ) void deleteuserbyempid(Integer empid);
	 */

}
