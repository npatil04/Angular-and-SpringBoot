import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { LoginserviceService } from './login/loginservice.service';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard  {

  constructor(private router:Router)
  {

  }

  
  
}
