import { Component, OnInit } from '@angular/core';
import { ColumnConfig } from 'material-dynamic-table';
import {MatPaginator} from '@angular/material/paginator';
import {MatSort} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';
import { AdminstaffService } from './adminstaff.service';
import {Leaves} from '../employee/Leaves'
import { from } from 'rxjs';
import { User } from '../user/user';
import { LoginserviceService } from '../login/loginservice.service';
@Component({
  selector: 'app-adminstaff',
  templateUrl: './adminstaff.component.html',
  styleUrls: ['./adminstaff.component.css']
})
export class AdminstaffComponent implements OnInit {
  
  emplist:Leaves[];
  
  userlist:User[];
  dataSource:any;
  searchText;
  constructor(private adminstaffservice:AdminstaffService,private loginservice:LoginserviceService)
  {

  }

  ngOnInit()
  {
    
    this.getuserleave();
    this.getUserList();
  }
  
  getuserleave()
  {
     this.adminstaffservice.getLeaveList().subscribe(res=>{this.emplist=res;console.log(res)})
     console.log(this.emplist)
  }
  
  rejectLeave(id: number)
  {
    this.adminstaffservice.rejectLeave(id).subscribe(res=>{
      this.emplist=res;console.log(res)
    });
    console.log("Delete clicked");
  }
  
  approveLeave(id: number)
  {
    this.adminstaffservice.approveLeave(id).subscribe(res=>{
      this.emplist=res;console.log(res)
    });
    console.log(id+"Edit clicked");
  }
     
  calculateLOP(id: number){
    this.adminstaffservice.calculateLOP(id).subscribe(res=>{
     if(res == true){
      alert("Claculated LOP for user successfully");
     } else if(res == false){
      alert("LOP calculation falied");
     }
    });
  }

  getUserList(){
    this.adminstaffservice.getUserList().subscribe(res=>{
      this.userlist=res;console.log(res)
    });
    console.log("clicked");
  }
 
  logout()
  {
    this.loginservice.logout();
  }

}
