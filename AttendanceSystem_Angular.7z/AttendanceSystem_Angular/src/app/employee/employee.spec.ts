import { Leaves } from './Leaves';

describe('Employee', () => {
  it('should create an instance', () => {
    expect(new Leaves()).toBeTruthy();
  });
});
