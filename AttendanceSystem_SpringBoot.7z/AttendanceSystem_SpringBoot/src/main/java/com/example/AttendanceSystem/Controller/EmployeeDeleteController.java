package com.example.AttendanceSystem.Controller;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.example.AttendanceSystem.Dao.UserDao;
import com.example.AttendanceSystem.Model.User;


/**
 * @author narpatil
 *
 */
@RestController
@CrossOrigin(origins = "*")
public class EmployeeDeleteController 
{
	@Autowired
	private UserDao userDao;
	
	@GetMapping("/delete/{empId}")
	public List<User> deleteEmployee(@PathVariable("empId") Integer empId)
	{
		System.out.println("potdar");
		userDao.deleteuserbyempid(empId);	
		List<User> user=(List<User>) userDao.findByusergroup(3);
		return user; 
	}
}
