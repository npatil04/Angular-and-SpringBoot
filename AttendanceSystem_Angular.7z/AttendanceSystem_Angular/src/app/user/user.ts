import { Leaves } from '../employee/Leaves';

export class User {
    empid:number
	

	  username:string;
	
	 password:string;
	 firstname:string;
 	lastname:string;
	 email:string;
	 address:string;
	 phone:string;
	 userGroup:string;
	 leavecount:string;
}
