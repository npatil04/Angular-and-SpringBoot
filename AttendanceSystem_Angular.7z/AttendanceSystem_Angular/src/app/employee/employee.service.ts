import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Leaves } from './Leaves';
import { LossOfPay } from './LossOfPay';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  constructor(private http:HttpClient) { }

  addleave(leave:Leaves,id:number)
  {
    return this.http.post<any>("http://localhost:8081/applyleave/"+id,leave);
  }

  getEmpLop(id:number){
    return this.http.get<LossOfPay>("http://localhost:8081/getEmpLop/"+id);
  }
}
