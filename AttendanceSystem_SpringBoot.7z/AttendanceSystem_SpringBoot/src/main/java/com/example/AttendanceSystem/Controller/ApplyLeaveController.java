package com.example.AttendanceSystem.Controller;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.AttendanceSystem.Dao.UserDao;
import com.example.AttendanceSystem.Dao.leavesdao;
import com.example.AttendanceSystem.Model.Leaves;
import com.example.AttendanceSystem.Model.User;

/**
 * @author narpatil
 *
 */
@RestController
@CrossOrigin(origins = "*")
public class ApplyLeaveController {

	@Autowired
	private leavesdao leavedao;

	@Autowired
	private UserDao userdao;

	@RequestMapping(value = "/applyleave/{id}", method = RequestMethod.POST)
	// @PostMapping("/applyleave")
	public int leave(@RequestBody Leaves leave, @PathVariable("id") Integer id) {
		System.out.println(leave);
        int success;
		leave.setStatus("applied");

		leave.setUser(userdao.findById(id));
		User userobj = userdao.findById(id);
		System.out.println(userobj);
		if (userobj.getLeavecount() != 0) {
			if ((userobj.getLeavecount() - leave.getDays()) > -8) {
				System.out.println("huio");
				leavedao.save(leave);
				userobj.setLeavecount(userobj.getLeavecount() - leave.getDays());
				// userdao.updatebyempid( userobj.getLeavecount(), id);
               return success=1;
			}

			else {
				return success=0;
			}
		} else {
			leavedao.save(leave);
			userobj.setLeavecount(userobj.getLeavecount() - leave.getDays());
			// userdao.updatebyempid( userobj.getLeavecount(), id);
			return success=1;
		}
		

	}

}
