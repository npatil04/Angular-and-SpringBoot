import { Component } from "@angular/core";
import { User } from '../user/user';
import { UserserviceService } from '../user/userservice.service';
@Component(
    {
        selector: 'app-employee',
        templateUrl: './app.employee.component.html',
        styleUrls: ['./app.employee.component.css']
    }

)
export class AddEmployeeComponent {
    user:User=new User
    userlist:User[];
    constructor(private UserserviceService:UserserviceService) { }
    adduser()
{
  alert(this.user.empid)
    if(this.user.empid>0)
    {
       this.UserserviceService.updateuser(this.user,this.user.empid).subscribe(data=>{this.userlist=data})
       
    }
    else
    {
      this.UserserviceService.adduser(this.user).subscribe(data=>{this.userlist=data;console.log(this.userlist)})

    }
    
    this.clear()
  }
    clear()
    {
      this.user.address=""
      this.user.email=""
      this.user.firstname=""
      this.user.lastname=""
      this.user.password=""
      this.user.phone=""
      this.user.userGroup=""
      this.user.leavecount=""
      this.user.username=""
      this.user.empid=0
    }
}
