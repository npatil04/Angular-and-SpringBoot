package com.example.AttendanceSystem.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.example.AttendanceSystem.Dao.LopDao;
import com.example.AttendanceSystem.Dao.UserDao;
import com.example.AttendanceSystem.Dao.leavesdao;
import com.example.AttendanceSystem.Model.Leaves;
import com.example.AttendanceSystem.Model.LossOfPay;
import com.example.AttendanceSystem.Model.User;

@RestController
@CrossOrigin(origins = "*")
public class ApproveLeave {

	@Autowired
	private leavesdao dao;

	@Autowired
	private UserDao userdao;
	
	@Autowired
	private LopDao lopDao;

	@GetMapping("/leavelist")
	private Iterable<Leaves> get() {
		return dao.findbyremark();

	}

	@GetMapping("/reject/{id}")
	public List<Leaves> reject(@PathVariable("id") Integer id) {

		dao.update(id);
		System.out.println("dao"+dao);

		return dao.findbyremark();
	}

	@GetMapping("/approve/{id}")
	public List<Leaves> approve(@PathVariable("id") Integer id) {

		dao.updateapprove(id);
		Leaves leave = dao.findbyid(id);

		User user = leave.getUser();
		System.out.println("user"+user);

		int count = user.getLeavecount() - leave.getDays();

		 userdao.updatebyempid( count, user.getEmpid());

		return dao.findbyremark();
	}
	
	
	@GetMapping("/calculatelop/{id}")
	public Boolean calculateLOP(@PathVariable("id") Integer id) {
		System.out.println(" calculatelop for  employee id: "+ id);
		User user = userdao.findById(id);
		System.out.println(user.getEmpid()+" "+user.getLeavecount());
		int noOfAvailabelLeaves = user.getLeavecount();
		int paidLeaves = 0;
		if (noOfAvailabelLeaves < 0)
			paidLeaves = noOfAvailabelLeaves * -1;
		int totalSalary = (30 - paidLeaves) * 1000;

		LossOfPay lop = lopDao.findbyid(id);

		if (lop == null) {
			System.out.println("Create New Lop");
			lop = new LossOfPay();
			lop.setUser(user);
		}
		lop.setLop(totalSalary);

		return lopDao.save(lop) != null ? true : false;

	}

}
