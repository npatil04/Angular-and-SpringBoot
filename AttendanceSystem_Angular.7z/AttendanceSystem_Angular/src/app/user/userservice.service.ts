import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { User } from './user';

@Injectable({
  providedIn: 'root'
})
export class UserserviceService {

  constructor(private http:HttpClient) { }
  
  adduser(user:User)
  {
     return this.http.post<User[]>("http://localhost:8081/adduser",user)
  }

  getuser()
  {
     return this.http.get<User[]>("http://localhost:8081/getuser")
  }

  updateuser(user:User,empid:number)
  {
    return this.http.put<User[]>("http://localhost:8081/edituser/"+empid,user)
  }
  
  deleteuser(empid:number)
  {
    //alert("Are you sure you want to delete the record?")
    return  this.http.get<User[]>("http://localhost:8081/delete/"+empid)

  }

}
