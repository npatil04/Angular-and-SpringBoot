package com.example.AttendanceSystem.Model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreType;

@Entity
@Table

public class Leaves {

	@Id
	@GeneratedValue
	private int id;
	
	@Column
	private  String  status;
	
	@Column
	private String remark;

	@Column
	private String fromDate;

	@Column
	private String toDate;

	@Column
	private Integer days;
	
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name="empid")
	private User  user;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getFromDate() {
		return fromDate;
	}

	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}

	public String getToDate() {
		return toDate;
	}

	public void setToDate(String toDate) {
		this.toDate = toDate;
	}

	public int getDays() {
		return days;
	}

	public void setDays(int days) {
		this.days = days;
	}

	@Override
	public String toString() {
		return "Leaves [id=" + id + ", status=" + status + ", remark=" + remark + ", fromDate=" + fromDate + ", toDate="
				+ toDate + ", days=" + days + ", user=" + user + "]";
	}
	
}
