package com.example.AttendanceSystem.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Query;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.example.AttendanceSystem.Dao.UserDao;
import com.example.AttendanceSystem.Model.Login;
import com.example.AttendanceSystem.Model.User;

/**
 * @author narpatil
 *
 */
@RestController
@CrossOrigin(origins = "*")
public class AdminLoginController 
{
	@Autowired
	private UserDao userDao;
	
	@GetMapping("/login/{username}/{password}")
	public User loginadmin(@PathVariable("username") String username,@PathVariable("password") String password)
	{   
		System.out.println("demo");
		User user=userDao.findbyuser(username, password);
		System.out.println(user.getAddress());
		System.out.println(user);
		return  user;
	}
	
	
	
}
