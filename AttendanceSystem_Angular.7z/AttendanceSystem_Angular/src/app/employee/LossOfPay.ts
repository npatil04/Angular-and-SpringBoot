import { User } from '../user/user';
export class LossOfPay{
    lopId : number;
    lop : number;
    user : User;
}