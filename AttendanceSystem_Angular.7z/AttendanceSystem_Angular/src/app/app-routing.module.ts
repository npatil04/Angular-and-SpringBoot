import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { UserComponent } from './user/user.component';
import { LoginserviceService } from './login/loginservice.service';
import {LogoutComponent} from './LogOut/logout.component';
import {AddEmployeeComponent} from './AddEmployee/app.employee.component';
import {AppViewEmployee} from './ViewEmployee/app.viewEmployee.component';
import { EmployeeComponent } from './employee/employee.component';
import { AdminstaffComponent } from './adminstaff/adminstaff.component';

 
import { AuthGuard } from './auth.guard';
import { WelcomeComponent } from './welcome/welcome.component';
const routes: Routes = [
 
  { path: '', component: WelcomeComponent },

  { path: 'login', component: LoginComponent},
  { path: 'admin', component: UserComponent,canActivate:[LoginserviceService] },
  { path: 'logout', component: LogoutComponent },
  
  { path: 'addEmployee', component: AddEmployeeComponent,canActivate:[LoginserviceService]},
  { path: 'viewEmployee', component: AppViewEmployee,canActivate:[LoginserviceService] },
  { path: 'Employee', component: EmployeeComponent,canActivate:[LoginserviceService] },
  { path: 'adminstaff', component: AdminstaffComponent,canActivate:[LoginserviceService]}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
